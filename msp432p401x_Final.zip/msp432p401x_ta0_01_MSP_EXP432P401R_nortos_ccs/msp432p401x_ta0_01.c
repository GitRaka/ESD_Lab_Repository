/* --COPYRIGHT--,BSD_EX
 * Copyright (c) 2013, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *******************************************************************************
 *
 *                       MSP432 CODE EXAMPLE DISCLAIMER
 *
 * MSP432 code examples are self-contained low-level programs that typically
 * demonstrate a single peripheral function or device feature in a highly
 * concise manner. For this the code may rely on the device's power-on default
 * register values and settings such as the clock configuration and care must
 * be taken when combining code from several examples to avoid potential side
 * effects. Also see http://www.ti.com/tool/mspdriverlib for an API functional
 * library & https://dev.ti.com/pinmux/ for a GUI approach to peripheral configuration.
 *
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP432P401 Demo - Timer0_A3, Toggle P1.0, CCR0 Cont Mode ISR, DCO SMCLK
//
//  Description: Toggle P1.0 using software and TA_0 ISR. Timer0_A is
//  configured for continuous mode, thus the timer overflows when TAR counts
//  to CCR0. In this example, CCR0 is loaded with 50000.
//  ACLK = n/a, MCLK = SMCLK = TACLK = default DCO = ~3MHz
//
//           MSP432P401x
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |               |
//        |           P1.0|-->LED
//
//   William Goh
//   Texas Instruments Inc.
//   Oct 2016 (updated) | November 2013 (created)
//   Built with CCSv6.1, IAR, Keil, GCC
//******************************************************************************
#include "ti/devices/msp432p4xx/inc/msp.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

uint16_t DTCYC = 6553;
uint32_t j = 0;
uint8_t flag = 0;
uint8_t C = 0;
//volatile uint32_t temp = 10000;
volatile uint16_t temp = 26214;
char bfr[20];
char bufr[20];
char bufr1[20];

volatile long tempor;
volatile float IntDegF;
volatile float IntDegC;

//Function declaration for the function that modifies the width for the PWM logic for LED
void modify_pwm();

//Function declaration for the function that handles display of duty cycle
void UART_func();

int main(void) {
   WDT_A->CTL = WDT_A_CTL_PW |             // Stop WDT
           WDT_A_CTL_HOLD;

   // Variables to store the ADC temperature reference calibration value
   int32_t adcRefTempCal_1_2v_30;
   int32_t adcRefTempCal_1_2v_85;

   // Read the ADC temperature reference calibration value
   adcRefTempCal_1_2v_30 = TLV->ADC14_REF1P2V_TS30C;
   adcRefTempCal_1_2v_85 = TLV->ADC14_REF1P2V_TS85C;

   CS->KEY = CS_KEY_VAL;                   // Unlock CS module for register access
   CS->CTL0 = 0;                           // Reset tuning parameters
   CS->CTL0 = CS_CTL0_DCORSEL_3;           // Set DCO to 12MHz (nominal, center of 8-16MHz range)
   CS->CTL1 = CS_CTL1_SELA_2 |             // Select ACLK = REFO
              CS_CTL1_SELS_3 |             // SMCLK = DCO
              CS_CTL1_SELM_3;              // MCLK = DCO
   CS->KEY = 0;                            // Lock CS module from unintended accesses

   // Initialize the shared reference module
   // By default, REFMSTR=1 => REFCTL is used to configure the internal reference
   while(REF_A->CTL0 & REF_A_CTL0_GENBUSY);// If ref generator busy, WAIT
   REF_A->CTL0 |= REF_A_CTL0_VSEL_0 |      // Enable internal 1.2V reference
           REF_A_CTL0_ON;                  // Turn reference on

   REF_A->CTL0 &= ~REF_A_CTL0_TCOFF;       // Enable temperature sensor

   // Configure ADC - Pulse sample mode; ADC14_CTL0_SC trigger
   ADC14->CTL0 |= ADC14_CTL0_SHT0_6 |      // ADC ON,temperature sample period>5us
           ADC14_CTL0_ON |
           ADC14_CTL0_SHP;
   ADC14->CTL1 |= ADC14_CTL1_TCMAP;        // Enable internal temperature sensor
   ADC14->MCTL[0] = ADC14_MCTLN_VRSEL_1 |  // ADC input ch A22 => temp sense
          ADC14_MCTLN_INCH_22;
   ADC14->IER0 = 0x0001;                   // ADC_IFG upon conv result-ADCMEM0

   // Wait for reference generator to settle
   while(!(REF_A->CTL0 & REF_A_CTL0_GENRDY));
   ADC14->CTL0 |= ADC14_CTL0_ENC;


   P1->DIR &= ~(uint8_t) BIT4;
   P1->OUT |= BIT4;
   P1->REN |= BIT4;                         // Enable pull-up resistor (P1.4)
   P1->SEL0 &= ~BIT4;
   P1->SEL1 &= ~BIT4;
   P1->IES &= ~BIT4;                         // Interrupt on high-to-low transition
   P1->IFG = 0;                            // Clear all P1 interrupt flags
   P1->IE |= BIT4;                          // Enable interrupt for P1.4

   P1->DIR &= ~(uint8_t) BIT1;
   P1->OUT |= BIT1;
   P1->REN |= BIT1;                         // Enable pull-up resistor (P1.4)
   P1->SEL0 &= ~BIT1;
   P1->SEL1 &= ~BIT1;
   P1->IES &= ~BIT1;                         // Interrupt on high-to-low transition
   P1->IFG = 0;                            // Clear all P1 interrupt flags
   P1->IE |= BIT1;                          // Enable interrupt for P1.4

   // Configure UART pins
   P1->SEL0 |= BIT2 | BIT3;                // set 2-UART pin as secondary function

   // Configure UART
   EUSCI_A0->CTLW0 |= EUSCI_A_CTLW0_SWRST; // Put eUSCI in reset
   EUSCI_A0->CTLW0 = EUSCI_A_CTLW0_SWRST | // Remain eUSCI in reset
           EUSCI_B_CTLW0_SSEL__SMCLK;      // Configure eUSCI clock source for SMCLK

   EUSCI_A0->BRW = 6;                     // 12000000/16/115200
   EUSCI_A0->MCTLW = (8 << EUSCI_A_MCTLW_BRF_OFS) |
           EUSCI_A_MCTLW_OS16;

   EUSCI_A0->CTLW0 &= ~EUSCI_A_CTLW0_SWRST; // Initialize eUSCI
   EUSCI_A0->IFG &= ~EUSCI_A_IFG_RXIFG;     // Clear eUSCI RX interrupt flag
   EUSCI_A0->IE |= EUSCI_A_IE_RXIE;         // Enable USCI_A0 RX interrupt

   // Configure GPIO
   P1->DIR |= BIT0;
   P1->OUT |= BIT0;

   TIMER_A0->CCTL[0] = TIMER_A_CCTLN_CCIE | TIMER_A_CTL_IE & ~(TIMER_A_CCTLN_CAP); // TACCR0 interrupt enabled,compare mode
   TIMER_A0->CCR[0] = 65535;
   //TIMER_A0->CCR[1] = 10000;       //40% duty cycle
   TIMER_A0->CCR[1] = 26214;       //40% duty cycle
   TIMER_A0->CTL = TIMER_A_CTL_SSEL__SMCLK | // SMCLK, continuous mode
           TIMER_A_CTL_MC__CONTINUOUS;
   TIMER_A0->CCTL[1] =  TIMER_A_CCTLN_CCIE | TIMER_A_CTL_IE & ~(TIMER_A_CCTLN_CAP);
   ADC14->CTL0 |= ADC14_CTL0_SC;       // Sampling and conversion start

   // Enable global interrupt
   __enable_irq();

   //Enable timer interrupts
   NVIC->ISER[0] = 1 << ((TA0_0_IRQn) & 31);
   NVIC->ISER[0] = 1 << ((TA0_N_IRQn) & 31);

   // Enable UART interrupt
   NVIC->ISER[0] = 1 << ((EUSCIA0_IRQn) & 31);

   // Enable Port 1 interrupt on the NVIC
   NVIC->ISER[1] = 1 << ((PORT1_IRQn) & 31);

   // Enable ADC interrupt in NVIC module
   NVIC->ISER[0] = 1 << ((ADC14_IRQn) & 31);

   uint8_t k = 0;

   //Loop to stay in to keep waiting for the interrupt
   while (1)
   {
       ADC14->CTL0 |= ADC14_CTL0_SC;       // This starts the sampling alog with the conversion

       if( (1==flag) || (2==flag))
       {
           modify_pwm();
           flag = 0;
       }
       if(flag == 3)
       {
           UART_func();
       }
       if(flag == 4)
       {
           IntDegC = (((float) tempor - adcRefTempCal_1_2v_30) * (85 - 30)) /
                       (adcRefTempCal_1_2v_85 - adcRefTempCal_1_2v_30) + 30.0f;

           // Temperature in Fahrenheit
           // Tf = (9/5)*Tc | 32
           IntDegF = ((9 * IntDegC) / 5) + 32;
           if(C == 1)
           {
               sprintf(bufr, "Temperature in Celsius: %d", (uint16_t)IntDegC);
               EUSCI_A0->TXBUF = '\n';
               while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
               EUSCI_A0->TXBUF = '\r';
               while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
               while(bufr[k] != '\0')
               {
                    EUSCI_A0->TXBUF = bufr[k];
                    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
                    k++;
               }
               flag = 0;k=0;
           }
           else
           {
               k=0;
               EUSCI_A0->TXBUF = '\n';
               while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
               EUSCI_A0->TXBUF = '\r';
               while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
               sprintf(bufr1, "Temperature in Fahrenheit: %d", (uint16_t)IntDegF);
               while(bufr1[k] != '\0')
               {
                    EUSCI_A0->TXBUF = bufr1[k];
                    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
                    k++;
               }
               EUSCI_A0->TXBUF = '\n';
               while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
               EUSCI_A0->TXBUF = '\r';
               while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
               flag = 0;k=0;
           }
           memset(bufr,'\0', sizeof(bufr));
           memset(bufr1,'\0', sizeof(bufr1));
       }
   }
}

// Timer A0 interrupt service routine
void TA0_0_IRQHandler(void) {
   TIMER_A0->CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
   P1->OUT |= BIT0;
}
void TA0_N_IRQHandler(void) {
   TIMER_A0->CCTL[1] &= ~TIMER_A_CCTLN_CCIFG;
   P1->OUT &= ~BIT0;
}

// UART interrupt service routine
void EUSCIA0_IRQHandler(void)
{
    if (EUSCI_A0->IFG & EUSCI_A_IFG_RXIFG)
    {
        // Check if the TX buffer is empty first
        while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));

        // Echo the received character back
        EUSCI_A0->TXBUF = EUSCI_A0->RXBUF;
        if ((EUSCI_A0->RXBUF == 'p') || (EUSCI_A0->RXBUF == 'P'))
        {
            flag = 3;
        }
        if((EUSCI_A0->RXBUF == 't') || (EUSCI_A0->RXBUF == 'T'))
        {
            EUSCI_A0->TXBUF = '\n';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\n';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\r';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = 'C';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = ' ';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = 'o';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = 'r';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = ' ';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = 'F';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '?';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\n';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\r';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            flag = 4;

            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_RXIFG));       //wait for receive
            if((EUSCI_A0->RXBUF == 'C') || (EUSCI_A0->RXBUF == 'c'))
            {
                C=1;                                           //Celsius mode for temperature selected
            }
            else if ((EUSCI_A0->RXBUF == 'F') || (EUSCI_A0->RXBUF == 'f'))
            {
                C=0;                                           //Fahrenheit mode for temperature selected
            }
            else
            {
                C=1;                                           //Select default Celsius mode for temperature
            }
        }
        if((EUSCI_A0->RXBUF == 'i') || (EUSCI_A0->RXBUF == 'I'))
        {
            flag = 1;
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\n';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\r';
        }
        if((EUSCI_A0->RXBUF == 'd') || (EUSCI_A0->RXBUF == 'D'))
        {
            flag = 2;
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\n';
            while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
            EUSCI_A0->TXBUF = '\r';
        }
    }
}

void UART_func()
{
     EUSCI_A0->TXBUF = 32;
//     if((uint16_t)((temp*100)/65535) > 89)
//     {
//         sprintf(bfr, "\n\rCurrent Duty Cycle is: %d", (uint16_t)100);
//     }
//     else if((uint16_t)((temp*100)/65535) < 10)
//     {
//         sprintf(bfr, "\n\rCurrent Duty Cycle is: %d", (uint16_t)0);
//     }
//     else

     sprintf(bfr, "\n\rCurrent Duty Cycle is: %d", (uint16_t)((temp*100)/65535));

     uint8_t l = 0;
     while(bfr[l] != '\0')
     {
         EUSCI_A0->TXBUF = bfr[l];
         while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));       //wait for transmit
         l++;
     }
     EUSCI_A0->TXBUF = '%';
     flag = 0;
}

void PORT1_IRQHandler(void)
{
    volatile uint32_t i;
    // Toggling the output on the LED
    if(P1->IFG & BIT4)
    {
        flag = 1;
    }
    if(P1->IFG & BIT1)
    {
        flag = 2;
    }
    // Delay for switch debounce
    for(i = 0; i < 10000; i++);

    //Clear switch interrupt flags
    P1->IFG &= ~BIT4;
    P1->IFG &= ~BIT1;
}

// ADC14 interrupt service routine
void ADC14_IRQHandler(void)
{
    if (ADC14->IFGR0 & ADC14_IFGR0_IFG0)
    {
        tempor = ADC14->MEM[0];
    }
}

void modify_pwm()
{
    if(1 == flag)
    {
        //if(temp < 10000)
        //if(temp < 26214)

        if(temp < (65535 - DTCYC))
        {
            if(temp < 6553)
            {
               //temp = 10000;
               //temp = 26214;
               temp = 6553;
               TIMER_A0->CCR[1] = temp;
            }
            else
            {
                TIMER_A0->CCR[1] = temp + DTCYC;
                temp += DTCYC;
            }
        }
        else if(temp > (65535 - DTCYC))
        {
            //TIMER_A0->CCR[1] = 10000;
            //TIMER_A0->CCR[1] = 26214;
            TIMER_A0->CCR[1] = (65534);
            //temp = 10000;
            temp = (65534);
        }
        else
        {
            //TIMER_A0->CCR[1] = 10000;
            TIMER_A0->CCR[1] = 65535 - DTCYC;
            //temp = 10000;
            temp = 65535 - DTCYC;
        }
    }
    if(2 == flag)
    {
        //if(temp >= 16553)
        //if(temp >= 32767)
        if(temp >= 6553)
        {
            TIMER_A0->CCR[1] = temp - (DTCYC);
            temp -= DTCYC;
        }
        else
        {
            //TIMER_A0->CCR[1] = 10000;
            //TIMER_A0->CCR[1] = 26214;
            TIMER_A0->CCR[1] = 0;
            //temp = 10000;
            temp = 0;
        }
    }
}
