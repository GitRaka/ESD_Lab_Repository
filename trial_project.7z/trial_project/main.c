/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* File			- main.c			                       */
/* Name			- Rakesh Kumar 			                   */
/* Email		- rakesh.kumar@colorado.edu 	           */
/* Date 		- 10-18-2019			                   */
/* Description	- File with all the main implementation	   */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#define DEBUG
#include <mcs51/at89c51ed2.h>
#include <mcs51/mcs51reg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef DEBUG
#define DEBUGPORT(x) dataout(x)
#else
#define DEBUGPORT(x)
#endif // DEBUG

#define MAX_SIZE 20
int32_t i =0;
uint16_t num = 0;
volatile __data uint16_t cnt =0;
uint8_t flag = 0;
uint16_t str_cnt=0;
uint16_t tot_cnt=0;
__xdata uint8_t *bufferPtr[MAX_SIZE];

struct info
{
    __xdata uint8_t *bufStartAdr;
    uint16_t index;
    __xdata uint8_t *bufEndAdr;
    uint16_t bufSize;
    uint16_t strg_count;
    uint16_t free;
} ptr[MAX_SIZE];

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name		    - delay() 	    		   	                             */
/* Parameters	- void 						   	                         */
/* Return	    - void  						   	                     */
/* Description	- This is a simple delay function.                  	 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void delay()
{
    i = 0;
    while(i<60000)
    {
       i++;
    }
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name		    - dataout() 			   	                             */
/* Parameters	- int 						   	                         */
/* Return	    - void  						   	                     */
/* Description	- This is the function for enabling virtual debugger	 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void dataout(int x)
{
    int *ptr=NULL;
    ptr = 0xFFFF;
    *ptr = x;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name		    - getNum() 				   	                             */
/* Parameters	- void 						   	                         */
/* Return	    - uint8_t *						   	                     */
/* Description	- This is the function for getting numbers from user	 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
uint8_t * getNum()
{
    uint8_t buff[5] = {0};
    uint8_t i = 0;
    uint8_t temp;
    while(i < 5)
    {
        temp = getchar();
        tot_cnt++;
        printf_tiny("%c",temp);
        if(((temp>47)&&(temp<58)) || (temp == 13))
        {
            buff[i] = temp;
            if(temp == 13)
            {
                break;
            }
            if(i == 4)
            {
                buff[i]=13;
            }
            i++;
        }
        else
        {
            num = 0;
            i=0;
            printf_tiny("\n\rEnter the size again in numbers[0:9]:");
        }
    }
    num = 0;
    flag = 0;
    for(i=0 ;(buff[i]) != 13; i++)
    {
        num = ((num * 10) + (buff[i] - 48));
    }

    if((num<32)||(num>3200))
    {
        printf_tiny("\n\rOut of scope value for memory allocation, try again.");
        flag = 1;
    }
    else
    {
        flag = 0;
    }
    return buff;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name			- main() 				                           */
/* Parameters	- void 					                           */
/* Return		- int 					                           */
/* Description	- This is the main function to take care of inputs,*/
/* 				  call functions, etc.		                       */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void main(void)
{
    printf_tiny("\n\r\n\r\n\r");
    printf_tiny("\n\r------------------------------------------------------");
    printf_tiny("\n\r------Prototype software for Buffer manipulation------");
    printf_tiny("\n\r------------------------------------------------------\n\r");
    DEBUGPORT(0x01);
    cnt = 0;
    str_cnt =0;
    tot_cnt=0;
    uint8_t recv;
    __xdata uint8_t *bufzeradr = NULL;
    do
    {
        printf_tiny("\n\r\n\rEnter the no of bytes to be allocated for buffer0 and buffer1[32,3200] in bytes:\n\r");
        uint8_t * size_bytes = getNum();
        if((num%16) != 0)
        {
            printf_tiny("\n\rThe memory size requested is not a multiple of 16.");
            flag = 1;
            continue;
        }
        if( 1 == flag)
        {
            continue;
        }
        DEBUGPORT(0x02);
        // Allocating the buffers
        if(flag == 0)
        {
            printf_tiny("\n\r%d",num);
            if ((bufferPtr[0] = malloc(num)) == 0)
            {
                printf_tiny("\n\rMalloc for buffer0 failed");
                free(bufferPtr[0]);
                ptr[0].bufStartAdr = 0;
                continue;
            }
            else
            {
                cnt = 0;
                ptr[0].index = cnt;
                ptr[0].bufSize = num;
                ptr[0].bufStartAdr = bufferPtr[0];
                printf("ptr[cnt].bufStartAdr-->%p",ptr[0].bufStartAdr);
                ptr[0].strg_count = str_cnt;
                ptr[0].free = ((ptr[0].bufSize) - (ptr[0].strg_count * 8));
                ptr[0].bufEndAdr = (ptr[0].bufStartAdr) + ((ptr[0].bufSize)/sizeof(uint8_t));
                cnt = cnt + 1;
                printf_small("\n\rMalloc has passed for buffer 0");
            }
            if ((bufferPtr[1] = malloc(num)) == 0)
            {
                printf_tiny("Malloc for buffer1 failed\n\r");
                free(bufferPtr[0]);
                free(bufferPtr[1]);
                ptr[0].bufStartAdr = 0;
                ptr[1].bufStartAdr = 0;
                continue;
            }
            else
            {
                cnt = 1;
                ptr[1].index = cnt;
                ptr[1].bufSize = num;
                ptr[1].bufStartAdr = bufferPtr[1];
                printf("ptr[cnt].bufStartAdr-->%p",ptr[1].bufStartAdr);
                ptr[1].strg_count = str_cnt;
                ptr[1].free = num - str_cnt;
                ptr[1].bufEndAdr = (ptr[1].bufStartAdr) + ((ptr[1].bufSize)/sizeof(uint8_t));
                ptr[1].free = ((ptr[1].bufSize) - (ptr[1].strg_count * 8));
                cnt = cnt + 1;
                printf_small("\n\rMalloc has passed for buffer 1");
            }
        }
        else
        {
            bufferPtr[0]=bufferPtr[1]=0;
        }
        // Note: What happens if we can't allocate both buffers forever? Is this good code?
    //} while ((bufferPtr[0] == 0) || (bufferPtr[1] == 0));

    __data uint8_t loop_flag = 0;
    bufzeradr = ptr[0].bufStartAdr;

    //while(0 != flag)
    do
    {
        if(1 == loop_flag)
        {
            bufzeradr = ptr[0].bufStartAdr;
        }
        printf_tiny("\n\rEnter to proceed:");
        recv = getchar();
        tot_cnt++;
        putchar(recv);
        if((recv>96) && (recv<123))
        {
            DEBUGPORT(0x01);
            //*bufferPtr[0] = recv;
            //bufferPtr[0]++;
            *bufzeradr = recv;
            bufzeradr++;
            ptr[0].strg_count++;
            ptr[0].free = ((ptr[0].bufSize) - (ptr[0].strg_count));
        }
        else
        {
            printf_tiny("\n\r\n\r---Command character entered.---");
        }
        switch(recv)
        {
            case 43: printf_tiny("\n\r\n\r' + ' commmand recognised. Please specify size for the new buffer:[30:300]");
                     getNum();
                     if((num<30)||(num>300))
                     {
                        printf_tiny("\n\rEnter in the range[30:300]");
                        continue;
                     }
                     printf_tiny("\n\rThe entered size for the new buffer is: %d",num);
                     if((bufferPtr[cnt] = malloc(num)) == 0)
                     {
                        printf_tiny("\n\rMemory allocation for buffer %d failed",cnt);
                        ptr[cnt].bufStartAdr = NULL;
                     }
                     else
                     {
                        printf_tiny("\n\rMemory allocated, buffer %d created",cnt+1);
                        ptr[cnt].index = cnt;
                        printf_tiny("\n\rInside '+' case ptr[%d]->index, %d",cnt,ptr[cnt].index);
                        ptr[cnt].bufSize = num;
                        ptr[cnt].bufStartAdr = bufferPtr[cnt];
                        ptr[cnt].strg_count = str_cnt;
                        ptr[cnt].free = ((ptr[cnt].bufSize) - (ptr[cnt].strg_count * 8));
                        ptr[cnt].bufEndAdr = (ptr[cnt].bufStartAdr) + ((ptr[cnt].bufSize)/sizeof(uint8_t));
                        cnt = cnt + 1;
                     }
                     break;

             case 45: printf_tiny("\n\r\n\r' - ' command recognised.");
                      printf_tiny("\n\rEnter the buffer index:");
                      uint16_t bfsel = getchar();
                      tot_cnt++;
                      bfsel -= 48;
                      printf_tiny("bfsel-->%d, cnt-->%d",bfsel,cnt);
                      if((bfsel <= cnt) && (bfsel > 0))
                      {
                         printf_tiny("\n\rValid buffer select entered. Clearing..");
                         free(bufferPtr[bfsel]);
                         ptr[bfsel].bufStartAdr = NULL;
                      }
                      else
                      {
                          printf_tiny("\n\rInvalid buffer selected!!");
                      }
                      break;

             case 63: printf_tiny("\n\r\n\r' ? ' command recognised.");
                      uint8_t i=0;
                      for(i=0; i<cnt; i++)
                      {
                        if(ptr[i].bufStartAdr == NULL)
                        {
                            continue;
                        }
                        printf("\n\rptr[%d]->bufStartAdr : %p",i,ptr[i].bufStartAdr);
                        printf_tiny("\n\rptr[%d]->index       : %d",i,ptr[i].index);
                        printf("\n\rptr[%d]->bufEndAdr   : %p",i,ptr[i].bufEndAdr);
                        printf_tiny("\n\rptr[%d]->bufSize     : %d",i,ptr[i].bufSize);
                        printf_tiny("\n\rptr[%d]->strg_count  : %d",i,ptr[i].strg_count);
                        printf_tiny("\n\rptr[%d]->free        : %d",i,ptr[i].free);
                        printf_tiny("\n\r");
                      }
                      printf_tiny("\n\rThe total characters entered: %d",tot_cnt);
                      tot_cnt = 0;
                      printf_tiny("\n\r\n\rFlushing buffer 0...\n\r");

                      __data uint8_t line_size = 0;
                      __xdata uint8_t *bufstraddr = ptr[0].bufStartAdr;

                      for(line_size =0; line_size<ptr[0].strg_count;line_size++)
                      {
                          if(0 == line_size%64)
                          {
                            printf_tiny("\n\r");
                          }
                          printf_tiny("%c ",*(bufstraddr + line_size));
                          *(bufstraddr + line_size) = 0;
                      }
                      bufzeradr = ptr[0].bufStartAdr;
                      break;

             case 61: printf_tiny("\n\r\n\r' = ' command recognised.");
                      __data uint8_t lin_size = 0;
                      __xdata uint8_t *bufstradr = ptr[0].bufStartAdr;
                      printf("\n\rptr[0].bufStartAdr%p",ptr[0].bufStartAdr);
                      if(0 != ptr[0].bufStartAdr)
                      {
                          for(lin_size =0; lin_size<ptr[0].strg_count;lin_size++)
                          {
                            if(0 == lin_size%16)
                            {
                                printf_tiny("\n\r");
                                printf("%p: ",(bufstradr + lin_size));
                            }
                            printf_tiny("%c ",*(bufstradr + lin_size));
                           }
                      }
                      else
                      {
                            printf_tiny("\n\r Empty buffer 0");
                      }
                      break;

             case 64: printf_tiny("\n\r\n\r' @ ' command recognised.");
                      __data uint8_t iter = 0;
                      printf_tiny("\n\r Freeing the allocated buffers...");
                       for(iter; iter<cnt ; iter++)
                       {
                         printf_tiny("\n\r Clearing bufferPtr[%d]",iter);
                         free(bufferPtr[iter]);
                         bufferPtr[iter] = 0;
                         ptr[iter].bufStartAdr = 0;
                       }
                       loop_flag = 1;
                       cnt = 0;
                       break;
        }

    } while(1 != loop_flag);

    } while ((bufferPtr[0] == 0) || (bufferPtr[1] == 0));
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name			- putchar()				                           */
/* Parameters	- int 					                           */
/* Return		- int 					                           */
/* Description	- This is the function that echos a character to   */
/* 				  the terminal.                                    */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
int putchar(int t)
{
    while(!TI);
    SBUF = t;
    TI = 0;
    return 1;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name			- putchar()				                           */
/* Parameters	- int 					                           */
/* Return		- int 					                           */
/* Description	- This is the function that gets a character from  */
/* 				  the terminal.                                    */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
int getchar(void)
{
    while(!RI);
    RI = 0;
    return SBUF;
}
