/*
 */
#include <mcs51/at89c51ed2.h>
#include <mcs51/mcs51reg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#define HEAP_SIZE 4000
//unsigned int xdata heap[HEAP_SIZE];
//__asm (".org 0x3000")
#define MAX_SIZE 20
int32_t i =0;
uint16_t num = 0;
volatile __data uint16_t cnt =0;
uint8_t flag = 0;
uint16_t str_cnt=0;
uint16_t tot_cnt=0;
__xdata uint8_t *bufferPtr[MAX_SIZE];

struct info
{
    __xdata uint8_t *bufStartAdr;
    uint16_t index;
    __xdata uint8_t *bufEndAdr;
    uint16_t bufSize;
    uint16_t strg_count;
    uint16_t free;
} ptr[MAX_SIZE];

void delay()
{
    i = 0;
    while(i<60000)
    {
       i++;
    }
}

uint8_t * getNum()
{
    uint8_t buff[5] = {0};
    uint8_t i = 0;
    uint8_t temp;
    while(i < 5)
    {
        //printf_tiny("\n\rInside getNum while");
        temp = getchar();
        tot_cnt++;
        //printf_tiny("\n\r%d",temp);
        if(((temp>47)&&(temp<58)) || (temp == 13))
        {
            buff[i] = temp;
            if(temp == 13){break;}
            if(i == 4)
            {
                buff[i]=13;
            }
            //printf_tiny("%d",buff[i]);
            i++;
        }
        else
        {
            num = 0;
            i=0;
            printf_tiny("\n\rEnter the size again in numbers[0:9]:");
        }
    }
    //debugging purpose
    while((i--) > 0 )
    {
        printf_tiny("\n\rbuff[%d]--%d",i,buff[i]);
    }
    num = 0;
    flag = 0;
    for(i=0 ;(buff[i]) != 13; i++)
    {
        printf_tiny("\n\rnum-->%d",num);
        num = ((num * 10) + (buff[i] - 48));
    }

    printf("\n\rnum-->%d",num);
    if((num<32)||(num>3200))
    {
        printf_tiny("\n\rOut of scope value for memory allocation, try again.");
        flag = 1;
    }
    else
    {
        flag = 0;
    }
    return buff;
}
//__sdcc_external_startup()
//{
    //AUXR |= 0x0C;
    //return 0;
//}

//void initUART()
//{
//    SCON = 0x50;
//    TMOD = 0x20;
//    TH1 = 0xFD;
//    TR1 = 1;
//}

// Insert code
void main(void)
{
    //__sdcc_heap_init();
    //initUART();
    //__xdata uint8_t* buffer;
    //__xdata uint8_t* buffer1;
    cnt = 0;
    str_cnt =0;
    tot_cnt=0;
    uint8_t recv;
    do
    {
        printf_tiny("\n\rEnter the no of bytes to be allocated in the range of [32,3200]bytes:");
        uint8_t * size_bytes = getNum();
        //*size_bytes-=48;
        printf_tiny("\n\rsize_bytes--> %s",size_bytes);
        if((num%16) != 0)
        {
            printf_tiny("\n\rThe memory size requested is not a multiple of 16.");
            flag = 1;
        }

        // Allocate the buffers
        if(flag == 0)
        {
            printf_tiny("\n\r%d",num);
            if ((bufferPtr[0] = malloc(num)) == 0)
                {printf_tiny("malloc for buffer0 failed\n\r");}
            else
            {
                printf("\n\r%p",bufferPtr[0]);
                printf_tiny("\n\rbuffer0 cnt-->%d",cnt);
                ptr[cnt].index = cnt;
                printf_tiny("\n\rptr[%d]->index, %d",cnt,ptr[cnt].index);
                ptr[cnt].bufSize = num;
                ptr[cnt].bufStartAdr = bufferPtr[0];
                printf("\n\rptr[%d]->bufStartAdr, %p",cnt,ptr[cnt].bufStartAdr);
                ptr[cnt].strg_count = str_cnt;
                printf_tiny("\n\rptr[cnt].strg_count-->%d",ptr[cnt].strg_count);
                ptr[cnt].free = ((ptr[cnt].bufSize) - (ptr[cnt].strg_count * 8));
                ptr[cnt].bufEndAdr = (ptr[cnt].bufStartAdr) + ((ptr[cnt].bufSize)/sizeof(uint8_t));
                cnt = cnt + 1;
                printf("\n\rcnt-->%d",cnt);
            }
            if ((bufferPtr[1] = malloc(num)) == 0)
            {
                printf_tiny("malloc for buffer1 failed\n\r");
                // if buffer1 malloc fails, free buffer 0
                free(bufferPtr[0]);
            }
            else
            {
                printf("\n\r%p",bufferPtr[1]);
                printf_tiny("\n\rbuffer1 cnt-->%d",cnt);
                ptr[cnt].index = cnt;
                printf_tiny("\n\rptr[%d]->index, %d",cnt,ptr[cnt].index);
                ptr[cnt].bufSize = num;
                ptr[cnt].bufStartAdr = bufferPtr[1];
                printf("\n\rptr[%d]->bufStartAdr, %p",cnt,ptr[cnt].bufStartAdr);
                ptr[cnt].strg_count = str_cnt;
                ptr[cnt].free = num - str_cnt;
                ptr[cnt].bufEndAdr = (ptr[cnt].bufStartAdr) + ((ptr[cnt].bufSize)/sizeof(uint8_t));
                ptr[cnt].free = ((ptr[cnt].bufSize) - (ptr[cnt].strg_count * 8));
                cnt = cnt + 1;
                printf_tiny("\n\rcnt-->%d",cnt);
            }
        }
        else
        {
            bufferPtr[0]=bufferPtr[1]=0;
        }
        // Note: What happens if we can't allocate both buffers forever? Is this good code?
    } while ((bufferPtr[0] == 0) || (bufferPtr[1] == 0));

    printf_small("malloc has passed\n\r");
    while(1)
    {
        printf_tiny("\n\rEnter to proceed:");
        recv = getchar();
        tot_cnt++;
        putchar(recv);
        if((recv>96) && (recv<123))
        {
            *bufferPtr[0] = recv;
            printf_tiny("\n\rEntered storage charcter is: %c",*bufferPtr[0]);
            bufferPtr[0]++;
            //str_cnt++;
            //printf_tiny("\n\rThe storage count is: %d",(ptr[0]->strg_count));
            ptr[0].strg_count++;
            printf_tiny("\n\rcnt is: %d",cnt);
            printf_tiny("\n\rThe storage count is: %d",(ptr[0].strg_count));
            ptr[0].free = ((ptr[0].bufSize) - (ptr[0].strg_count));
            printf_tiny("\n\rptr[0].free-->%d",ptr[0].free);
        }
        else
        {
            printf_tiny("\n\rCommand character entered.");
        }
        switch(recv)
        {
            case 43: printf_tiny("\n\r' + ' commmand recognised. Please specify size for the new buffer:[30:300]");
                     getNum();
                     if((num<30)||(num>300))
                     {
                        printf_tiny("\n\rEnter in the range[30:300]");
                        continue;
                     }
                     printf_tiny("\n\rThe entered size for the new buffer is:%d",num);
                     if((bufferPtr[cnt] = malloc(num)) == 0)
                     {
                        printf_tiny("Memory allocation for buffer %d failed",cnt);
                     }
                     else
                     {
                        printf_tiny("Memory allocated, buffer %d created",cnt);
                        ptr[cnt].index = cnt;
                        printf_tiny("\n\rInside '+' case ptr[%d]->index, %d",cnt,ptr[cnt].index);
                        ptr[cnt].bufSize = num;
                        ptr[cnt].bufStartAdr = bufferPtr[cnt];
                        printf("\n\rptr[%d]->bufStartAdr, %p",cnt,ptr[cnt].bufStartAdr);
                        ptr[cnt].strg_count = str_cnt;
                        printf_tiny("\n\rptr[cnt].strg_count-->%d",ptr[cnt].strg_count);
                        ptr[cnt].free = ((ptr[cnt].bufSize) - (ptr[cnt].strg_count * 8));
                        ptr[cnt].bufEndAdr = (ptr[cnt].bufStartAdr) + ((ptr[cnt].bufSize)/sizeof(uint8_t));
                        cnt = cnt + 1;
                     }
                     break;

             case 45: printf_tiny("\n\r' - ' command recognised.");
                      printf_tiny("\n\rEnter the buffer index:");
                      uint16_t bfsel = getchar();
                      tot_cnt++;
                      bfsel -= 48;
                      printf_tiny("bfsel-->%d, cnt-->%d",bfsel,cnt);
                      if((bfsel <= cnt) && (bfsel > 0))
                      {
                         printf_tiny("\n\rValid buffer select entered. Clearing..");
                         free(bufferPtr[bfsel]);
                         ptr[bfsel].bufStartAdr = NULL;
                         cnt--;
                      }
                      else
                      {
                          printf_tiny("\n\rInvalid buffer selected!!");
                      }
                      break;

             case 63: printf_tiny("\n\r' ? ' command recognised.");
                      uint8_t i=0;
                      printf_tiny("?-->cnt---> %d",cnt);
                      for(i=0; i<cnt; i++)
                      {
                        if(ptr[i].bufStartAdr == NULL)
                        {
                            continue;
                        }
                        printf("\n\rptr[%d]->bufStartAdr : %p",i,ptr[i].bufStartAdr);
                        printf_tiny("\n\rptr[%d]->index       : %d",i,ptr[i].index);
                        printf("\n\rptr[%d]->bufEndAdr   : %p",i,ptr[i].bufEndAdr);
                        printf_tiny("\n\rptr[%d]->bufSize     : %d",i,ptr[i].bufSize);
                        printf_tiny("\n\rptr[%d]->strg_count  : %d",i,ptr[i].strg_count);
                        printf_tiny("\n\rptr[%d]->free        : %d",i,ptr[i].free);
                        printf_tiny("\n\r");
                      }
                      printf_tiny("\n\rThe total characters entered: %d",tot_cnt);
                      tot_cnt = 0;
                      printf_tiny("\n\rFlushing buffer 0 below....\n\r");

                      __data uint8_t line_size = 0;
                      __xdata uint8_t *bufstraddr = ptr[0].bufStartAdr;

                      for(line_size =0; line_size<ptr[0].strg_count;line_size++)
                      {
                          if(0 == line_size%64)
                          {
                            printf_tiny("\n\r");
                          }
                          printf_tiny("%c ",*(bufstraddr + line_size));
                          *(bufstraddr + line_size) = 0;
                      }
                      break;

             case 61: printf_tiny("\n\r' = ' command recognised.");
                      __data uint8_t lin_size = 0;
                      __xdata uint8_t *bufstradr = ptr[0].bufStartAdr;
                      for(lin_size =0; lin_size<ptr[0].strg_count;lin_size++)
                      {
                          if(0 == lin_size%16)
                          {
                            printf_tiny("\n\r");
                            printf("%p: ",bufstradr + lin_size);
                          }
                          printf_tiny("%c ",*(bufstradr + lin_size));
                      }
                      break;

             case 64: printf_tiny("\n\r ' @ ' command recognised.");
                      __data uint8_t iter = 0;
                      printf_tiny("\n\r Freeing the allocated buffers...");
                       for(iter; iter<cnt ; iter++)
                       {
                         printf_tiny("\n\r Clearing bufferPtr[%d]--> %d",iter,bufferPtr[cnt]);
                         free(bufferPtr[cnt]);
                         bufferPtr[cnt] = 0;
                       }
        }
        //printf_tiny("\n\r%c, %d, %d",recv,recv,*buffer0);
        //printf("\n\r%p",buffer0);

        //printf_tiny("\n\rEnter the command to process:");
        //cmd = getchar();

//        P1 = 0b10010011;
//        while(i<60000)
//        {
//            i++;
//        }
//        i = 0;
//        P1 = 0b01101100;
//        while(i<60000)
//        {
//            i++;
//        }
//        i=0;
//        P1 = 0b10010011;
        /*P1_2 = !P1_2;
        delay();
        //P1 = 0b01101100;
        P1_2 = !P1_2;*/
        //delay();
        //bufferPtr[0]++;
    }
    //return;
    //free(buffer0);
}

int putchar(int t)
{
    while(!TI);
    //while(TI == 0);
    //while ((SCON & 0x02) == 0);
    SBUF = t;
    TI = 0;
    return 1;
}

int getchar(void)
{
    while(!RI);
    //while
    //while((SCON & 0x01) == 0);
    //while(RI == 0);
    RI = 0;
    return SBUF;
}
//void putchar (char c)
//{
//	if((!SIO_SM0)&&(!SIO_SM1)) inituart(0xff);
//	if (c=='\n')
//	{
//		while (!SIO_TI);
//		SIO_TI=0;
//		SIO_SBUF='\r';
//	}
//	while (!SIO_TI);
//	SIO_TI=0;
//	SIO_SBUF=c;
//}

