/*
 */
#include <mcs51/at89c51ed2.h>
#include <mcs51/mcs51reg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#define HEAP_SIZE 4000
//unsigned int xdata heap[HEAP_SIZE];
//__asm (".org 0x3000")
#define MAX_SIZE 20
int32_t i =0;
uint16_t num = 0;
uint16_t cnt =0;
uint8_t flag = 0;
uint16_t str_cnt=0;
uint16_t tot_cnt=0;
__xdata uint8_t *bufferPtr[MAX_SIZE];

struct info
{
    __xdata uint8_t *bufStartAdr;
    uint16_t index;
    __xdata uint8_t *bufEndAdr;
    uint16_t bufSize;
    uint16_t strg_count;
    uint16_t free;
}*ptr[MAX_SIZE];

void delay()
{
    i = 0;
    while(i<60000)
    {
       i++;
    }
}

uint8_t * getNum()
{
    uint8_t buff[5] = {0};
    uint8_t i = 0;
    uint8_t temp;
    while(i < 5)
    {
        //printf_tiny("\n\rInside getNum while");
        temp = getchar();
        //printf_tiny("\n\r%d",temp);
        if(((temp>47)&&(temp<58)) || (temp == 13))
        {
            buff[i] = temp;
            if(temp == 13){break;}
            if(i == 4)
            {
                buff[i]=13;
            }
            //printf_tiny("%d",buff[i]);
            i++;
        }
        else
        {
            num = 0;
            i=0;
            printf_tiny("\n\rEnter the size again in numbers[0:9]:");
            //continue;
        }
    }
    while((i--) > 0 )
    {
        printf_tiny("\n\rbuff[%d]--%d",i,buff[i]);
    }
    num = 0;
    flag = 0;
    for(i=0 ;(buff[i]) != 13; i++)
    {
        printf_tiny("\n\rnum-->%d",num);
        num = ((num * 10) + (buff[i] - 48));
    }

    printf("\n\rnum-->%d",num);
    if((num<32)||(num>3200))
    {
        printf_tiny("\n\rOut of scope value for memory allocation, try again.");
        flag = 1;
    }
    else
    {
        flag = 0;
    }
    return buff;
}
//__sdcc_external_startup()
//{
    //AUXR |= 0x0C;
    //return 0;
//}

//void initUART()
//{
//    SCON = 0x50;
//    TMOD = 0x20;
//    TH1 = 0xFD;
//    TR1 = 1;
//}

// Insert code
void main(void)
{
    //__sdcc_heap_init();
    //initUART();
    //__xdata uint8_t* buffer;
    //__xdata uint8_t* buffer1;
    cnt = 0;str_cnt =0;tot_cnt=0;
    uint8_t recv;
    do
    {
        printf_tiny("\n\rEnter the no of bytes to be allocated in the range of [32,3200]bytes:");
        uint8_t * size_bytes = getNum();
        //*size_bytes-=48;
        printf_tiny("\n\rsize_bytes--> %s",size_bytes);
        if((num%16) != 0)
        {
            printf_tiny("The memory size requested is not a multiple of 16.");
            flag = 1;
        }

        // Allocate the buffers
        if(flag == 0)
        {
            printf_tiny("\n\r%d",num);
            if ((bufferPtr[0] = malloc(num)) == 0)
                {printf_tiny("malloc for buffer0 failed\n\r");}
            else
            {
                cnt++;
            }
            if ((bufferPtr[1] = malloc(num)) == 0)
            {
                printf_tiny("malloc for buffer1 failed\n\r");
                // if buffer1 malloc fails, free buffer 0
                free(bufferPtr[0]);
            }
            else
            {
                  cnt++;
            }
        }
        else
        {
            bufferPtr[0]=bufferPtr[1]=0;
        }
        // Note: What happens if we can't allocate both buffers forever? Is this good code?
    } while ((bufferPtr[0] == 0) || (bufferPtr[1] == 0));

    printf_small("malloc has passed\n\r");
    printf("address bufferPtr[0]-->%p",bufferPtr[0]);
    //buffer = bufferPtr[0];
    while(1)
    {
        //printf_tiny("\n\rStuff's running\n\r");
        printf_tiny("\n\rEnter the command to process:");
        recv = getchar();
        if((recv>96) && (recv<123))
        {
            *bufferPtr[0] = recv;
            bufferPtr[0]++;
            str_cnt++;
            tot_cnt++;
        }
        else
        {
            printf_tiny("\n\rCommand character entered.");
        }
        switch(recv)
        {
            case 43: printf_tiny("\n\r' + ' commmand recognised. Please specify size for the new buffer:[30:300]");
                     getNum();
                     if((num<30)||(num>300))
                     {
                        printf_tiny("\n\rEnter in the range[30:300]");
                        continue;
                     }
                     printf_tiny("\n\rThe entered size for the new buffer is:%d",num);
                     if((bufferPtr[cnt] = malloc(num)) == 0)
                     {
                        printf_tiny("Memory allocation for buffer %d failed",cnt);
                     }
                     else
                     {
                        printf_tiny("Memory allocated, buffer %d created",cnt);
                        cnt++;
                     }
                     break;

             case 45: printf_tiny("\n\r' - ' command recognised.");
                      printf_tiny("\n\rEnter the buffer index:");
                      uint16_t bfsel = getchar();
                      bfsel -= 48;
                      printf_tiny("bfsel-->%d, cnt-->%d",bfsel,cnt);
                      if((bfsel <= cnt) && (bfsel > 0))
                      {
                         printf_tiny("\n\rValid buffer select entered. Clearing..");
                         free(bufferPtr[bfsel]);
                      }
                      else
                      {
                          printf_tiny("\n\rInvalid buffer selected!!");
                      }
                      break;

             case 63: printf_tiny("\n\r' ? ' command recognised.");

        }
        //printf_tiny("\n\r%c, %d, %d",recv,recv,*buffer0);
        //printf("\n\r%p",buffer0);

        //printf_tiny("\n\rEnter the command to process:");
        //cmd = getchar();

//        P1 = 0b10010011;
//        while(i<60000)
//        {
//            i++;
//        }
//        i = 0;
//        P1 = 0b01101100;
//        while(i<60000)
//        {
//            i++;
//        }
//        i=0;
//        P1 = 0b10010011;
        /*P1_2 = !P1_2;
        delay();
        //P1 = 0b01101100;
        P1_2 = !P1_2;*/
        delay();
        //bufferPtr[0]++;
    }
    //return;
    //free(buffer0);
}

int putchar(int t)
{
    while(!TI);
    //while(TI == 0);
    //while ((SCON & 0x02) == 0);
    SBUF = t;
    TI = 0;
    return 1;
}

int getchar(void)
{
    while(!RI);
    //while
    //while((SCON & 0x01) == 0);
    //while(RI == 0);
    RI = 0;
    return SBUF;
}
//void putchar (char c)
//{
//	if((!SIO_SM0)&&(!SIO_SM1)) inituart(0xff);
//	if (c=='\n')
//	{
//		while (!SIO_TI);
//		SIO_TI=0;
//		SIO_SBUF='\r';
//	}
//	while (!SIO_TI);
//	SIO_TI=0;
//	SIO_SBUF=c;
//}

